#!/usr/bin/env bash
# Shows what a package does WITHOUT launching it (never launch factory/production/AT/fac-menu packages).
# Usage: tools/inspect.sh <package> [<package> ...]    or    tools/inspect.sh --list
source "$(dirname "$0")/common.sh"
need_tv

if [ "${1:-}" = "--list" ]; then
  D="$(latest_backup)"; [ -n "$D" ] || { echo "Run tools/backup.sh first"; exit 1; }
  echo "== Manufacturer-looking packages (xiaomi / mi / mitv / mediatek / amlogic / realtek) =="
  sed 's/^package://; s/^.*=//' "$D/packages.txt" | grep -Ei 'xiaomi|mitv|\.mi\.|mediatek|amlogic|realtek|miui|patchwall' | sort
  echo
  echo "== Third-party (user-installed) =="
  sed 's/^package://' "$D/packages-third-party.txt" | sort
  exit 0
fi

for P in "$@"; do
  echo "================ $P ================"
  tvsh dumpsys package "$P" | grep -E 'versionName|firstInstallTime|flags=|  [A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+ ' | head -40
  echo "-- actions/categories it answers to --"
  tvsh dumpsys package "$P" | grep -E 'Action: |Category: ' | sort -u | head -25
done
