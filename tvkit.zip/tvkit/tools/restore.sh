#!/usr/bin/env bash
# Re-enables everything this kit disabled, and restores private DNS to what it was.
# Usage: TV=ip:5555 tools/restore.sh [backup-dir]     (default: latest)
source "$(dirname "$0")/common.sh"
need_tv
D="${1:-$(latest_backup)}"
[ -d "$D" ] || { echo "No backup folder found ($D)"; exit 1; }

LOG="$D/disabled-by-kit.txt"
if [ -s "$LOG" ]; then
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    echo "enabling $p"
    tvsh pm enable "$p"
  done < "$LOG"
else
  echo "No packages were recorded as disabled in $LOG"
fi

# anything that was NOT disabled when the backup was taken but is disabled now:
tvsh pm list packages -d | tr -d '\r' | sort > /tmp/now-disabled.$$
sort "$D/packages-disabled-before.txt" | tr -d '\r' > /tmp/was-disabled.$$
EXTRA="$(comm -13 /tmp/was-disabled.$$ /tmp/now-disabled.$$ | sed 's/^package://')"
rm -f /tmp/now-disabled.$$ /tmp/was-disabled.$$
for p in $EXTRA; do echo "enabling $p (was enabled at backup time)"; tvsh pm enable "$p"; done

# private DNS
MODE="$(grep '^private_dns_mode=' "$D/settings-global.txt" | cut -d= -f2 | tr -d '\r')"
SPEC="$(grep '^private_dns_specifier=' "$D/settings-global.txt" | cut -d= -f2 | tr -d '\r')"
tvsh settings put global private_dns_mode "${MODE:-opportunistic}"
[ -n "$SPEC" ] && tvsh settings put global private_dns_specifier "$SPEC"

echo
echo "Done. To go back to the factory launcher: enable it (it is in $D/home-claimants.txt) with"
echo "  tvsh pm enable <package>   and   adb shell cmd package set-home-activity <package>/<activity>"
echo "Then reboot the TV."
