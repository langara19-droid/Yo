package com.tvlauncher.clean;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Clean Apple-TV-style home screen. No blur, no video, no network.
 * Navigation is handled here (not by Android focus) so that the D-pad is deterministic.
 */
public class MainActivity extends Activity {

    private static final int ZONE_TOP = 0, ZONE_DOCK = 1, ZONE_GRID = 2;
    private static final String PREFS = "launcher";

    static class AppEntry {
        String pkg;
        CharSequence label;
        Drawable img;
        boolean banner;
        Intent intent;
        int glow = 0xFF3A3A3C;
    }

    // layout units: 1u = screenHeight / 540 px
    private float u;
    private int W, H, margin, cols, cellW, rowH;
    private Typeface font;

    private final List<AppEntry> dock = new ArrayList<>();
    private final List<AppEntry> grid = new ArrayList<>();

    private int zone = ZONE_DOCK, topIdx = 0, lastTop = 0, dockIdx = 0, gridIdx = 0;
    private boolean menuOpen = false;
    private int menuIdx = 0;
    private final List<TvInputInfo> menuInputs = new ArrayList<>();
    private final List<TextView> menuRows = new ArrayList<>();

    private FrameLayout root, page, dockBand, glowView, menuPanel, header;
    private TextView nameView, greetView, wifiLabel;
    private final List<Cell> dockCells = new ArrayList<>();
    private final List<FrameLayout> pills = new ArrayList<>();
    private RecyclerView gridRv;
    private GridAdapter gridAdapter;
    private GradientDrawable glowDrawable;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        DisplayMetrics dm = getResources().getDisplayMetrics();
        W = dm.widthPixels;
        H = dm.heightPixels;
        u = H / 540f;
        margin = (int) (56 * u);
        cols = Math.max(2, Math.min(7, getResources().getInteger(R.integer.columns)));
        cellW = (W - 2 * margin) / cols;
        rowH = (int) (140 * u);
        try {
            font = Typeface.createFromAsset(getAssets(), "fonts/Outfit.ttf");
        } catch (Exception e) {
            font = Typeface.create("sans-serif-light", Typeface.NORMAL);
        }
        buildUi();
        loadAppsAsync();
        askLocationOnce();
    }

    // ------------------------------------------------------------------ UI

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setClipChildren(true);
        setContentView(root);

        // optional wallpaper: put wallpaper.jpg in res/drawable-nodpi/ (see README)
        int wp = getResources().getIdentifier("wallpaper", "drawable", getPackageName());
        if (wp != 0) {
            try {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageResource(wp);
                iv.setColorFilter(0xAA000000, android.graphics.PorterDuff.Mode.DARKEN);
                root.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            } catch (Throwable ignored) { }
        }

        page = new FrameLayout(this);
        page.setClipChildren(false);
        root.addView(page, new FrameLayout.LayoutParams(W, (int) (820 * u)));

        // ambient glow behind the big app name
        glowView = new FrameLayout(this);
        glowDrawable = new GradientDrawable();
        glowDrawable.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glowDrawable.setGradientRadius(330 * u);
        glowDrawable.setGradientCenter(0.3f, 0.6f);
        glowDrawable.setColors(new int[]{0x00000000, 0x00000000});
        glowView.setBackground(glowDrawable);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams((int) (760 * u), (int) (280 * u));
        glp.leftMargin = margin - (int) (60 * u);
        glp.topMargin = (int) (200 * u);
        page.addView(glowView, glp);

        nameView = text("", 40, 300);
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(W - 2 * margin, (int) (60 * u));
        nlp.leftMargin = margin;
        nlp.topMargin = (int) (306 * u);
        page.addView(nameView, nlp);

        dockBand = new FrameLayout(this);
        GradientDrawable band = new GradientDrawable();
        band.setColor(0x24FFFFFF);
        band.setCornerRadius(30 * u);
        dockBand.setBackground(band);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(cellW, (int) (120 * u));
        dlp.leftMargin = margin;
        dlp.topMargin = (int) (380 * u);
        page.addView(dockBand, dlp);

        gridRv = new RecyclerView(this);
        gridRv.setLayoutManager(new GridLayoutManager(this, cols));
        gridRv.setItemAnimator(null);
        gridRv.setClipChildren(false);
        gridRv.setClipToPadding(false);
        gridRv.setFocusable(false);
        gridRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        gridAdapter = new GridAdapter();
        gridRv.setAdapter(gridAdapter);
        FrameLayout.LayoutParams glp2 = new FrameLayout.LayoutParams(W - 2 * margin, (int) (280 * u));
        glp2.leftMargin = margin;
        glp2.topMargin = (int) (520 * u);
        page.addView(gridRv, glp2);

        // fixed header: greeting, clock, date, pills
        header = new FrameLayout(this);
        root.addView(header, new FrameLayout.LayoutParams(-1, (int) (170 * u)));

        greetView = text("", 22, 300);
        FrameLayout.LayoutParams g = new FrameLayout.LayoutParams(-2, (int) (34 * u));
        g.leftMargin = margin;
        g.topMargin = (int) (28 * u);
        header.addView(greetView, g);

        TextClock clock = new TextClock(this);
        clock.setFormat24Hour(getString(R.string.time_format));
        clock.setFormat12Hour(getString(R.string.time_format));
        styleText(clock, 76, 200);
        FrameLayout.LayoutParams c = new FrameLayout.LayoutParams(-2, (int) (96 * u));
        c.leftMargin = margin;
        c.topMargin = (int) (52 * u);
        header.addView(clock, c);

        TextClock date = new TextClock(this);
        date.setFormat24Hour(getString(R.string.date_format));
        date.setFormat12Hour(getString(R.string.date_format));
        styleText(date, 20, 300);
        date.setAlpha(0.7f);
        FrameLayout.LayoutParams d = new FrameLayout.LayoutParams(-2, (int) (30 * u));
        d.leftMargin = margin;
        d.topMargin = (int) (140 * u);
        header.addView(date, d);

        LinearLayout pillRow = new LinearLayout(this);
        pillRow.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams pr = new FrameLayout.LayoutParams(-2, (int) (40 * u));
        pr.gravity = Gravity.TOP | Gravity.END;
        pr.topMargin = (int) (28 * u);
        pr.rightMargin = margin;
        header.addView(pillRow, pr);
        pillRow.addView(makePill(getString(R.string.inputs)));
        FrameLayout wifi = makePill(getString(R.string.wifi));
        wifiLabel = (TextView) wifi.getChildAt(0);
        pillRow.addView(wifi);
        pillRow.addView(makePill(getString(R.string.settings)));

        menuPanel = new FrameLayout(this);
        menuPanel.setVisibility(View.GONE);
        root.addView(menuPanel, new FrameLayout.LayoutParams(-2, -2));
    }

    private FrameLayout makePill(String label) {
        FrameLayout p = new FrameLayout(this);
        TextView t = text(label, 18, 400);
        t.setGravity(Gravity.CENTER);
        t.setPadding((int) (20 * u), 0, (int) (20 * u), 0);
        p.addView(t, new FrameLayout.LayoutParams(-2, -1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -1);
        lp.leftMargin = (int) (12 * u);
        p.setLayoutParams(lp);
        pills.add(p);
        paintPill(p, false);
        return p;
    }

    private void paintPill(FrameLayout p, boolean sel) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(20 * u);
        g.setColor(sel ? 0x66FFFFFF : 0x26FFFFFF);
        p.setBackground(g);
        p.animate().scaleX(sel ? 1.08f : 1f).scaleY(sel ? 1.08f : 1f).setDuration(110).start();
    }

    private TextView text(String s, float sizeU, int wght) {
        TextView t = new TextView(this);
        t.setText(s);
        styleText(t, sizeU, wght);
        return t;
    }

    private void styleText(TextView t, float sizeU, int wght) {
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        t.setTypeface(font);
        t.setSingleLine(true);
        t.setIncludeFontPadding(false);
        if (Build.VERSION.SDK_INT >= 26) {
            try { t.setFontVariationSettings("'wght' " + wght); } catch (Throwable ignored) { }
        }
    }

    // ------------------------------------------------------------------ tiles

    class Cell extends FrameLayout {
        final ImageView img;
        final TextView label;
        final boolean showLabel;
        final float selScale;

        Cell(Context c, boolean showLabel) {
            super(c);
            this.showLabel = showLabel;
            this.selScale = showLabel ? 1.10f : 1.08f;
            setClipChildren(false);
            img = new ImageView(c);
            final float radius = 12 * u;
            img.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
                }
            });
            img.setClipToOutline(true);
            int iw = (int) (cellW * 0.84f);
            int ih = iw * 9 / 16;
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(iw, ih);
            if (showLabel) {
                ip.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                ip.topMargin = (int) (12 * u);
            } else {
                ip.gravity = Gravity.CENTER;
            }
            addView(img, ip);
            label = text("", 16, 400);
            label.setGravity(Gravity.CENTER);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            label.setAlpha(0f);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, (int) (26 * u));
            lp.gravity = Gravity.TOP;
            lp.topMargin = (int) (12 * u) + ih + (int) (10 * u);
            if (showLabel) addView(label, lp);
        }

        void bind(AppEntry e) {
            if (e.banner) {
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                img.setPadding(0, 0, 0, 0);
                img.setBackground(null);
            } else {
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int p = (int) (10 * u);
                img.setPadding(p, p, p, p);
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(0xFF1C1C1E);
                img.setBackground(bg);
            }
            img.setImageDrawable(e.img);
            label.setText(e.label);
        }

        void setSel(boolean s) {
            if (s) {
                GradientDrawable g = new GradientDrawable();
                g.setCornerRadius(20 * u);
                g.setColor(0x33FFFFFF);
                setBackground(g);
            } else {
                setBackground(null);
            }
            animate().scaleX(s ? selScale : 1f).scaleY(s ? selScale : 1f).setDuration(110).start();
            label.animate().alpha(s ? 1f : 0f).setDuration(110).start();
        }
    }

    class VH extends RecyclerView.ViewHolder {
        final Cell cell;
        VH(Cell c) {
            super(c);
            cell = c;
        }
    }

    class GridAdapter extends RecyclerView.Adapter<VH> {
        @Override
        public VH onCreateViewHolder(ViewGroup parent, int type) {
            Cell c = new Cell(parent.getContext(), true);
            c.setLayoutParams(new RecyclerView.LayoutParams(cellW, rowH));
            return new VH(c);
        }

        @Override
        public void onBindViewHolder(VH h, int pos) {
            h.cell.bind(grid.get(pos));
            h.cell.setSel(zone == ZONE_GRID && pos == gridIdx && !menuOpen);
        }

        @Override
        public int getItemCount() {
            return grid.size();
        }
    }

    // ------------------------------------------------------------------ apps

    private void loadAppsAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<AppEntry> all = queryApps();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        applyApps(all);
                    }
                });
            }
        }).start();
    }

    private List<AppEntry> queryApps() {
        PackageManager pm = getPackageManager();
        Map<String, AppEntry> map = new HashMap<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || map.containsKey(pkg)) continue;
                AppEntry e = new AppEntry();
                e.pkg = pkg;
                e.label = ri.loadLabel(pm);
                Drawable banner = null;
                try { banner = ri.activityInfo.loadBanner(pm); } catch (Throwable ignored) { }
                if (banner != null && cat.equals(Intent.CATEGORY_LEANBACK_LAUNCHER)) {
                    e.img = banner;
                    e.banner = true;
                } else {
                    e.img = ri.loadIcon(pm);
                    e.banner = false;
                }
                e.glow = sampleColor(e.img);
                e.intent = new Intent(Intent.ACTION_MAIN).addCategory(cat)
                        .setClassName(pkg, ri.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                map.put(pkg, e);
            }
        }
        return new ArrayList<>(map.values());
    }

    /** Average colour weighted by saturation, from a 16x9 downscale. */
    private int sampleColor(Drawable d) {
        try {
            Bitmap bm = Bitmap.createBitmap(16, 9, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bm);
            Drawable copy = d.getConstantState() != null ? d.getConstantState().newDrawable().mutate() : d;
            copy.setBounds(0, 0, 16, 9);
            copy.draw(c);
            float r = 0, g = 0, bl = 0, wsum = 0;
            float[] hsv = new float[3];
            for (int y = 0; y < 9; y++) {
                for (int x = 0; x < 16; x++) {
                    int p = bm.getPixel(x, y);
                    if (Color.alpha(p) < 40) continue;
                    Color.colorToHSV(p, hsv);
                    float w = 0.05f + hsv[1] * hsv[2];
                    r += Color.red(p) * w;
                    g += Color.green(p) * w;
                    bl += Color.blue(p) * w;
                    wsum += w;
                }
            }
            bm.recycle();
            if (wsum <= 0) return 0xFF3A3A3C;
            return Color.rgb((int) (r / wsum), (int) (g / wsum), (int) (bl / wsum));
        } catch (Throwable t) {
            return 0xFF3A3A3C;
        }
    }

    private void applyApps(List<AppEntry> all) {
        Map<String, AppEntry> byPkg = new HashMap<>();
        for (AppEntry e : all) byPkg.put(e.pkg, e);

        dock.clear();
        grid.clear();
        Set<String> used = new HashSet<>();
        for (String pkg : getResources().getStringArray(R.array.dock_apps)) {
            AppEntry e = byPkg.get(pkg.trim());
            if (e != null && dock.size() < cols && used.add(e.pkg)) dock.add(e);
        }
        List<AppEntry> rest = new ArrayList<>();
        for (AppEntry e : all) if (!used.contains(e.pkg)) rest.add(e);
        Collections.sort(rest, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                return a.label.toString().compareToIgnoreCase(b.label.toString());
            }
        });
        grid.addAll(rest);

        dockBand.removeAllViews();
        dockCells.clear();
        dockBand.getLayoutParams().width = Math.max(1, dock.size()) * cellW;
        dockBand.setVisibility(dock.isEmpty() ? View.GONE : View.VISIBLE);
        for (int i = 0; i < dock.size(); i++) {
            Cell c = new Cell(this, false);
            c.bind(dock.get(i));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(cellW, -1);
            lp.leftMargin = i * cellW;
            dockBand.addView(c, lp);
            dockCells.add(c);
        }
        dockBand.requestLayout();
        gridAdapter.notifyDataSetChanged();

        restoreSelection();
        refresh();
    }

    private void restoreSelection() {
        String last = prefs.getString("last_pkg", null);
        String lastZone = prefs.getString("last_zone", "dock");
        zone = dock.isEmpty() ? (grid.isEmpty() ? ZONE_TOP : ZONE_GRID) : ZONE_DOCK;
        dockIdx = 0;
        gridIdx = 0;
        if (last == null) return;
        for (int i = 0; i < dock.size(); i++) {
            if (dock.get(i).pkg.equals(last)) {
                zone = ZONE_DOCK;
                dockIdx = i;
                return;
            }
        }
        for (int i = 0; i < grid.size(); i++) {
            if (grid.get(i).pkg.equals(last)) {
                gridIdx = i;
                if (lastZone.equals("grid")) zone = ZONE_GRID;
                return;
            }
        }
    }

    private void saveSelection() {
        AppEntry e = null;
        String z = "dock";
        if (zone == ZONE_GRID && gridIdx < grid.size()) {
            e = grid.get(gridIdx);
            z = "grid";
        } else if (dockIdx < dock.size() && !dock.isEmpty()) {
            e = dock.get(dockIdx);
        }
        if (e != null) prefs.edit().putString("last_pkg", e.pkg).putString("last_zone", z).apply();
    }

    // ------------------------------------------------------------------ state -> view

    private int lastGridIdx = -1;

    private void refresh() {
        // pills
        for (int i = 0; i < pills.size(); i++) {
            paintPill(pills.get(i), zone == ZONE_TOP && i == topIdx && !menuOpen);
        }
        // dock cells
        for (int i = 0; i < dockCells.size(); i++) {
            dockCells.get(i).setSel(zone == ZONE_DOCK && i == dockIdx && !menuOpen);
        }
        // grid
        if (lastGridIdx >= 0 && lastGridIdx < grid.size()) updateGridSel(lastGridIdx, false);
        if (zone == ZONE_GRID && gridIdx < grid.size()) {
            updateGridSel(gridIdx, !menuOpen);
            gridRv.smoothScrollToPosition(gridIdx);
            lastGridIdx = gridIdx;
        } else {
            lastGridIdx = -1;
        }
        // big name + glow above the dock
        boolean showName = zone == ZONE_DOCK && !dock.isEmpty() && dockIdx < dock.size() && !menuOpen;
        nameView.animate().alpha(showName ? 1f : 0f).setDuration(120).start();
        glowView.animate().alpha(showName ? 1f : 0f).setDuration(160).start();
        if (!dock.isEmpty() && dockIdx < dock.size()) {
            AppEntry e = dock.get(Math.min(dockIdx, dock.size() - 1));
            nameView.setText(e.label);
            glowDrawable.setColors(new int[]{(e.glow & 0xFFFFFF) | 0x66000000, 0x00000000});
        }
        // scroll the page up when in the grid, hide the header there
        page.animate().translationY(zone == ZONE_GRID ? -250 * u : 0).setDuration(180).start();
        header.animate().alpha(zone == ZONE_GRID ? 0f : 1f).setDuration(150).start();
        saveSelection();
    }

    private void updateGridSel(int pos, boolean sel) {
        RecyclerView.ViewHolder vh = gridRv.findViewHolderForAdapterPosition(pos);
        if (vh instanceof VH) ((VH) vh).cell.setSel(sel);
        else gridAdapter.notifyItemChanged(pos);
    }

    // ------------------------------------------------------------------ keys

    @Override
    public boolean onKeyDown(int key, KeyEvent ev) {
        if (menuOpen) {
            handleMenuKey(key, ev);
            return true;
        }
        boolean repeat = ev.getRepeatCount() > 0;
        switch (key) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (!repeat) moveUp();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (!repeat) moveDown();
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                moveSide(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                moveSide(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (!repeat) activate();
                return true;
            case KeyEvent.KEYCODE_BACK:
                if (zone == ZONE_GRID && !dock.isEmpty()) {
                    zone = ZONE_DOCK;
                    dockIdx = Math.min(gridIdx % cols, dock.size() - 1);
                    refresh();
                }
                return true; // a launcher never exits
            default:
                return super.onKeyDown(key, ev);
        }
    }

    private void moveUp() {
        if (zone == ZONE_GRID) {
            if (gridIdx / cols > 0) {
                gridIdx -= cols;
            } else if (!dock.isEmpty()) {
                zone = ZONE_DOCK;
                dockIdx = Math.min(gridIdx % cols, dock.size() - 1);
            } else {
                zone = ZONE_TOP;
                topIdx = lastTop;
            }
        } else if (zone == ZONE_DOCK) {
            zone = ZONE_TOP;
            topIdx = lastTop;
        }
        refresh();
    }

    private void moveDown() {
        if (zone == ZONE_TOP) {
            lastTop = topIdx;
            if (!dock.isEmpty()) zone = ZONE_DOCK;
            else if (!grid.isEmpty()) zone = ZONE_GRID;
        } else if (zone == ZONE_DOCK) {
            if (!grid.isEmpty()) {
                zone = ZONE_GRID;
                gridIdx = Math.min(dockIdx, grid.size() - 1);
            }
        } else if (zone == ZONE_GRID) {
            int next = gridIdx + cols;
            if (next < grid.size()) {
                gridIdx = next;
            } else if ((gridIdx / cols + 1) * cols < grid.size()) {
                gridIdx = grid.size() - 1; // partial last row
            }
        }
        refresh();
    }

    private void moveSide(int dir) {
        if (zone == ZONE_TOP) {
            topIdx = Math.max(0, Math.min(pills.size() - 1, topIdx + dir));
            lastTop = topIdx;
        } else if (zone == ZONE_DOCK) {
            dockIdx = Math.max(0, Math.min(dock.size() - 1, dockIdx + dir));
        } else if (zone == ZONE_GRID) {
            int col = gridIdx % cols;
            int n = gridIdx + dir;
            if (n >= 0 && n < grid.size() && (dir < 0 ? col > 0 : col < cols - 1)) gridIdx = n;
        }
        refresh();
    }

    private void activate() {
        if (zone == ZONE_TOP) {
            if (topIdx == 0) openMenu();
            else if (topIdx == 1) startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS));
            else startSafe(new Intent(Settings.ACTION_SETTINGS));
        } else if (zone == ZONE_DOCK && dockIdx < dock.size()) {
            startSafe(dock.get(dockIdx).intent);
        } else if (zone == ZONE_GRID && gridIdx < grid.size()) {
            startSafe(grid.get(gridIdx).intent);
        }
    }

    private void startSafe(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ inputs menu

    private void openMenu() {
        menuInputs.clear();
        menuRows.clear();
        menuPanel.removeAllViews();
        TvInputManager tim = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
        if (tim != null) {
            for (TvInputInfo info : tim.getTvInputList()) {
                int t = info.getType();
                if (t == TvInputInfo.TYPE_HDMI || t == TvInputInfo.TYPE_COMPOSITE
                        || t == TvInputInfo.TYPE_SVIDEO || t == TvInputInfo.TYPE_COMPONENT
                        || t == TvInputInfo.TYPE_TUNER) {
                    menuInputs.add(info);
                }
            }
        }
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (10 * u);
        col.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF01C1C1E);
        bg.setCornerRadius(22 * u);
        col.setBackground(bg);
        if (menuInputs.isEmpty()) {
            TextView t = text(getString(R.string.no_inputs), 18, 400);
            t.setPadding(pad * 2, pad, pad * 2, pad);
            col.addView(t);
        }
        for (TvInputInfo info : menuInputs) {
            CharSequence label = info.loadCustomLabel(this);
            if (label == null || label.length() == 0) label = info.loadLabel(this);
            TextView row = text(label.toString(), 18, 400);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding((int) (18 * u), 0, (int) (18 * u), 0);
            col.addView(row, new LinearLayout.LayoutParams((int) (280 * u), (int) (44 * u)));
            menuRows.add(row);
        }
        menuPanel.addView(col);
        // place under the Inputs pill (first pill)
        int[] loc = new int[2];
        pills.get(0).getLocationInWindow(loc);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.leftMargin = Math.max(margin / 2, Math.min(loc[0], W - (int) (300 * u) - margin / 2));
        lp.topMargin = loc[1] + (int) (48 * u);
        menuPanel.setLayoutParams(lp);
        menuPanel.setVisibility(View.VISIBLE);
        menuOpen = true;
        menuIdx = 0;
        paintMenu();
        refresh();
    }

    private void paintMenu() {
        for (int i = 0; i < menuRows.size(); i++) {
            TextView r = menuRows.get(i);
            if (i == menuIdx) {
                GradientDrawable g = new GradientDrawable();
                g.setColor(0x44FFFFFF);
                g.setCornerRadius(14 * u);
                r.setBackground(g);
            } else {
                r.setBackground(null);
            }
        }
    }

    private void closeMenu() {
        menuOpen = false;
        menuPanel.setVisibility(View.GONE);
        refresh();
    }

    private void handleMenuKey(int key, KeyEvent ev) {
        switch (key) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (ev.getRepeatCount() == 0 && menuIdx > 0) { menuIdx--; paintMenu(); }
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (ev.getRepeatCount() == 0 && menuIdx < menuRows.size() - 1) { menuIdx++; paintMenu(); }
                break;
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                closeMenu();
                break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (ev.getRepeatCount() == 0 && menuIdx < menuInputs.size()) {
                    TvInputInfo info = menuInputs.get(menuIdx);
                    closeMenu();
                    openInput(info);
                }
                break;
            default:
                break;
        }
    }

    private void openInput(TvInputInfo info) {
        try {
            if (info.isPassthroughInput()) {
                startSafe(new Intent(Intent.ACTION_VIEW,
                        TvContract.buildChannelUriForPassthroughInput(info.getId())));
            } else {
                startSafe(new Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI));
            }
        } catch (Exception e) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ wifi / lifecycle

    private void askLocationOnce() {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && !prefs.getBoolean("asked_location", false)) {
            prefs.edit().putBoolean("asked_location", true).apply();
            try {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 7);
            } catch (Throwable ignored) { }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        updateWifi();
    }

    private void updateWifi() {
        String name = getString(R.string.wifi);
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
            String ssid = wi == null ? null : wi.getSSID();
            if (ssid != null && !ssid.equals("<unknown ssid>") && ssid.length() > 0) {
                if (ssid.startsWith("\"") && ssid.endsWith("\"") && ssid.length() > 1) {
                    ssid = ssid.substring(1, ssid.length() - 1);
                }
                name = ssid;
            }
        } catch (Throwable ignored) { }
        wifiLabel.setText(name);
    }

    private void updateGreeting() {
        int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        greetView.setText(h < 12 ? R.string.greet_morning : (h < 20 ? R.string.greet_afternoon : R.string.greet_evening));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateWifi();
        updateGreeting();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // HOME pressed while we are already in front: go back to the dock
        if (menuOpen) {
            menuOpen = false;
            menuPanel.setVisibility(View.GONE);
        }
        if (!dock.isEmpty()) {
            zone = ZONE_DOCK;
            dockIdx = Math.min(dockIdx, dock.size() - 1);
        }
        refresh();
    }
}
