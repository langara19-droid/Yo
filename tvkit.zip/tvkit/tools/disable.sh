#!/usr/bin/env bash
# Disables packages for user 0 (never uninstalls). Usage: tools/disable.sh batches/01-telemetry.txt
# One package per line; '#' starts a comment. Keep batches SMALL (3-6) and look at the TV between batches.
source "$(dirname "$0")/common.sh"

BATCH="${1:-}"
[ -f "$BATCH" ] || { echo "Usage: TV=ip:5555 $0 <batch-file>"; exit 1; }
need_tv
D="$(latest_backup)"; [ -n "$D" ] || { echo "Run tools/backup.sh first"; exit 1; }

# ---------------------------------------------------------------- protected list
EXTRA="$KIT_ROOT/tools/protected-extra.txt"   # your own additions, one glob per line

is_protected() {
  local p="$1"
  case "$p" in
    android|com.android.systemui|com.android.shell|com.android.phone|com.android.settings|\
    com.android.tv.settings|com.android.vending|com.google.android.gms|com.google.android.gsf|\
    com.android.permissioncontroller|com.google.android.permissioncontroller|\
    com.android.packageinstaller|com.google.android.packageinstaller|\
    com.android.ext.services|com.android.ext.shared|com.google.android.ext.services|\
    com.google.android.ext.shared|com.google.android.modulemetadata|com.android.modulemetadata|\
    com.android.inputdevices|com.android.keychain|com.android.certinstaller|com.android.defcontainer|\
    com.android.externalstorage|com.android.mtp|com.android.location.fused|com.android.captiveportallogin|\
    com.android.webview|com.google.android.webview|com.android.bluetooth|com.android.tv|com.google.android.tv|\
    com.tvlauncher.clean) return 0 ;;
    com.android.tv.*|com.google.android.tv.*|com.google.android.overlay.modules*|\
    com.android.providers.tv|com.google.android.networkstack*|com.android.networkstack*) return 0 ;;
    com.android.providers.calendar|com.android.providers.contacts|\
    com.android.providers.userdictionary|com.android.providers.blockednumber) ;;   # explicitly allowed
    com.android.providers.*) return 0 ;;
    *bluetooth*|*inputmethod*|*keyboard*|*remote*|*overlay*|*tvinput*|*.tvsettings*) return 0 ;;
    *factory*|*fac.menu*|*.hkcfac*|*production*|com.at.*) return 0 ;;   # never touch factory/AT packages
    com.netflix.*|com.amazon.amazonvideo*|com.amazon.avod*) return 0 ;;   # apps the owner uses
  esac
  if [ -f "$EXTRA" ]; then
    while IFS= read -r g; do
      [ -z "$g" ] && continue
      case "$g" in \#*) continue;; esac
      # shellcheck disable=SC2254
      case "$p" in $g) return 0;; esac
    done < "$EXTRA"
  fi
  return 1
}

PKGS=()
while IFS= read -r line; do
  line="${line%%#*}"; line="$(echo "$line" | tr -d '[:space:]')"
  [ -n "$line" ] && PKGS+=("$line")
done < "$BATCH"
[ "${#PKGS[@]}" -gt 0 ] || { echo "Batch is empty"; exit 1; }

# reject the WHOLE batch if any package is protected (a Mi TV Stick never booted after such a list)
BAD=0
for p in "${PKGS[@]}"; do
  if is_protected "$p"; then echo "REFUSED (protected): $p"; BAD=1; fi
done
[ "$BAD" -eq 0 ] || { echo "Nothing was changed. Remove the protected packages and retry."; exit 2; }

# also refuse whatever currently answers HOME (that must be handled by build-and-install.sh / README)
HOMES="$(tvsh cmd package query-activities -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | tr -d '\r')"
for p in "${PKGS[@]}"; do
  if echo "$HOMES" | grep -q "$p"; then
    echo "REFUSED: $p answers the HOME intent. Install our launcher and make it Home first (see README)."
    exit 2
  fi
done

LOG="$D/disabled-by-kit.txt"; touch "$LOG"
FAILS=0
for p in "${PKGS[@]}"; do
  if ! tvsh pm list packages "$p" | tr -d '\r' | grep -qx "package:$p"; then
    echo "skip (not installed): $p"; continue
  fi
  echo "disabling $p"
  tvsh pm disable-user --user 0 "$p"      # exactly one pm command per adb call
  # verify with the list, not the exit code
  if tvsh pm list packages -d | tr -d '\r' | grep -qx "package:$p"; then
    grep -qx "$p" "$LOG" || echo "$p" >> "$LOG"
  else
    echo "  !! $p is NOT disabled (firmware refused?)"; FAILS=$((FAILS+1))
  fi
done

echo
if [ "$FAILS" -eq "${#PKGS[@]}" ]; then
  echo "EVERY package was refused. Stop here: this firmware may not allow pm disable-user."
  echo "Do not retry in a loop. Use the TV's own privacy switches and private DNS instead."
fi
echo "Now look at the TV: does Home, the remote and the inputs menu still work? Then take the next batch."
