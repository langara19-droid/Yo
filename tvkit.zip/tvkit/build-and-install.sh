#!/usr/bin/env bash
# Builds the launcher, installs it over adb and (after asking) makes it the default Home.
# Needs: JDK 17, Android SDK (ANDROID_HOME set, platform 34 + build-tools), and either ./gradlew or `gradle` 8.4+.
#   export TV=192.168.1.50:5555 ; ./build-and-install.sh
set -u
source "$(dirname "$0")/tools/common.sh"
need_tv

PKG=com.tvlauncher.clean
ACT=$PKG/.MainActivity
L="$KIT_ROOT/launcher"

SDK="$(tvsh getprop ro.build.version.sdk | tr -d '\r')"
MINSDK="$(grep -E '^\s*minSdk' "$L/app/build.gradle" | grep -Eo '[0-9]+' | head -1)"
echo "TV SDK=$SDK, launcher minSdk=$MINSDK"
if [ "$SDK" -lt "$MINSDK" ]; then
  echo "This TV is older than the launcher's minSdk (it would answer INSTALL_FAILED_OLDER_SDK)."
  echo "Do not lower minSdk blindly: keep the factory launcher and only debloat."
  exit 1
fi

[ -d "$(latest_backup)" ] || { echo "Run tools/backup.sh first."; exit 1; }

build_apk() {
# --- font (Outfit, SIL Open Font License). Optional: the launcher falls back to a system font.
FONT="$L/app/src/main/assets/fonts/Outfit.ttf"
if [ ! -s "$FONT" ]; then
  mkdir -p "$(dirname "$FONT")"
  curl -fsSL -m 60 -o "$FONT" "https://github.com/google/fonts/raw/main/ofl/outfit/Outfit%5Bwght%5D.ttf" \
    || { rm -f "$FONT"; echo "Could not download Outfit. Put Outfit.ttf in $(dirname "$FONT") (see README) or continue with the fallback font."; }
fi

# --- build
cd "$L" || exit 1
if [ -x ./gradlew ]; then GR=./gradlew
elif command -v gradle >/dev/null 2>&1; then
  gradle wrapper --gradle-version 8.4 >/dev/null 2>&1 && GR=./gradlew || GR=gradle
else
  echo "Neither ./gradlew nor gradle found. Install Gradle 8.4+ (or open launcher/ in Android Studio and build 'debug')."; exit 1
fi
$GR assembleDebug || { echo "Build failed."; exit 1; }
APK="$L/app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || { echo "APK not found at $APK"; exit 1; }
cd "$KIT_ROOT" || exit 1
}

if [ -n "${APK:-}" ]; then
  [ -f "$APK" ] || { echo "APK=$APK does not exist"; exit 1; }
  echo "Using prebuilt APK: $APK"
else
  build_apk
fi

# --- install (adb install can hang waiting for an on-screen confirmation: fall back to pm install -r)
OUT="$( (command -v timeout >/dev/null 2>&1 && timeout 90 "$ADB" -s "$TV" install -r "$APK" 2>&1) || true)"
if ! echo "$OUT" | grep -q Success; then
  echo "adb install did not report Success (${OUT:-no output}); trying pm install -r via the shell..."
  tvadb push "$APK" /data/local/tmp/cleanlauncher.apk >/dev/null
  OUT="$(tvsh pm install -r /data/local/tmp/cleanlauncher.apk 2>&1)"
  tvsh rm /data/local/tmp/cleanlauncher.apk
fi
echo "$OUT"
if ! echo "$OUT" | grep -q Success; then
  if echo "$OUT" | grep -q 'VERIFICATION_FAILURE'; then
    echo "This TV refuses external APKs (INSTALL_FAILED_VERIFICATION_FAILURE). Launcher install is impossible here; stop trying."
  elif echo "$OUT" | grep -q 'OLDER_SDK'; then
    echo "TV SDK is below minSdk. Keep the factory launcher."
  fi
  exit 1
fi

# --- who answers HOME?
echo
echo "Apps that answer the HOME intent right now:"
tvsh cmd package query-activities -a android.intent.action.MAIN -c android.intent.category.HOME | tr -d '\r'
echo
read -r -p "Make $PKG the default Home? (y/N) " A
[ "$A" = "y" ] || { echo "Skipped. Set it later with: adb shell cmd package set-home-activity $ACT"; exit 0; }

tvsh cmd package set-home-activity "$ACT"
tvsh input keyevent KEYCODE_HOME
sleep 2
echo "Focused app now:"
tvsh dumpsys activity activities | grep -E 'mFocusedApp|mResumedActivity|ResumedActivity' | head -3
echo
echo "Check it with your own eyes: if Home still opens the factory launcher, set-home-activity printed Success but did nothing."
echo "Next: reboot the TV once, confirm Home and adb both come back, THEN consider disabling the factory launcher."
echo "Press every remote button (Home, Input, Settings, Netflix, Prime) and tell me which do nothing."
