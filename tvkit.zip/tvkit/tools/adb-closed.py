#!/usr/bin/env python3
"""Check that the TV's adb port is closed. Usage: tools/adb-closed.py <tv-ip> [port]

Only "Connection refused" proves the port is closed.
A timeout or "No route to host" proves nothing (on macOS, Local Network privacy can
cause it even when the port is open) - try from another machine or terminal.
"""
import errno
import socket
import sys


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 64
    host = sys.argv[1]
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 5555
    s = socket.socket()
    s.settimeout(5)
    try:
        s.connect((host, port))
    except ConnectionRefusedError:
        print(f"OK: {host}:{port} refused the connection - adb is closed.")
        return 0
    except socket.timeout:
        print("INCONCLUSIVE: timed out. The TV may still be rebooting, or something filters packets.")
        return 2
    except OSError as e:
        if e.errno == errno.ECONNREFUSED:
            print(f"OK: {host}:{port} refused the connection - adb is closed.")
            return 0
        print(f"INCONCLUSIVE: {e}. This is NOT proof that the port is closed.")
        return 2
    finally:
        s.close()
    print(f"OPEN: {host}:{port} accepted a connection. Turn USB/network debugging off and reboot.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
