#!/usr/bin/env bash
# Saves everything needed to undo changes BEFORE touching the TV.
source "$(dirname "$0")/common.sh"
need_tv

DIR="$BACKUP_ROOT/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DIR"
echo "$DIR" > "$BACKUP_ROOT/.latest"

echo "Backing up to $DIR"
tvsh pm list packages -f        > "$DIR/packages.txt"
tvsh pm list packages -d        > "$DIR/packages-disabled-before.txt"
tvsh pm list packages -3        > "$DIR/packages-third-party.txt"
tvsh getprop                    > "$DIR/getprop.txt"
tvsh settings list global       > "$DIR/settings-global.txt"
tvsh settings list secure       > "$DIR/settings-secure.txt"
tvsh settings list system       > "$DIR/settings-system.txt"
tvsh wm size                    > "$DIR/display.txt"
tvsh wm density                >> "$DIR/display.txt"
tvsh cmd package query-activities -a android.intent.action.MAIN -c android.intent.category.HOME \
                                > "$DIR/home-claimants.txt" 2>&1
tvsh dumpsys usb                > "$DIR/usb.txt" 2>&1
tvsh dumpsys connectivity       > "$DIR/connectivity.txt" 2>&1

SDK="$(tvsh getprop ro.build.version.sdk | tr -d '\r')"
SECURE="$(tvsh getprop ro.adb.secure | tr -d '\r')"
TRANSPORT="$(grep -o 'Transports: [A-Z]*' "$DIR/connectivity.txt" | head -1)"
echo
echo "Android SDK        : $SDK  (the launcher needs >= 26)"
echo "ro.adb.secure      : ${SECURE:-<empty>}   (0 = anyone on the LAN can get a shell while adb is open)"
echo "Network transport  : ${TRANSPORT:-unknown}"
echo "Home claimants     : see $DIR/home-claimants.txt"
echo
echo "Reminder: USB debugging can cut power to USB ports on some sets. Turn it off when finished."
echo "Restore later with:  TV=$TV tools/restore.sh"
