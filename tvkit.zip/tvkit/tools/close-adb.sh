#!/usr/bin/env bash
# Last step. Turns debugging off. The adb connection will drop; that is expected.
source "$(dirname "$0")/common.sh"
need_tv
echo "This disables developer options and adb on the TV. Make sure you are completely finished."
read -r -p "Continue? (y/N) " A
[ "$A" = "y" ] || exit 0
tvsh settings put global development_settings_enabled 0
tvsh settings put global adb_enabled 0
cat <<'EOF'

On the TV, also do these by hand:
  1. Settings > Device Preferences > Developer options: confirm USB debugging and network debugging are OFF
     and tap "Revoke USB debugging authorizations".
  2. Restart the TV.
Then, from your computer:   python3 tools/adb-closed.py <tv-ip>
Only "Connection refused" proves the port is closed (a timeout proves nothing).
Port 5555 is plain text and, on firmware with ro.adb.secure=0, anyone on your LAN could get a shell while it is open.
EOF
