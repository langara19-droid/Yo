# Kit: Xiaomi MiTV-MSSP2 (Android 9) — limpiar bloatware + pantalla de inicio estilo Apple TV

**Estado honesto:** este kit se ha escrito sin acceso al televisor. Los scripts pasan la comprobación de sintaxis y la lista de paquetes protegidos está probada con ejemplos, pero **el lanzador no se ha compilado ni probado en el televisor**, y no hay capturas. Lo que ves en pantalla es lo que debes verificar tú (o pegarme aquí) en cada paso.

## Qué hay

| Ruta | Para qué |
|---|---|
| `tools/backup.sh` | Copia de seguridad (paquetes, deshabilitados, `getprop`, settings, pantalla, Home). Se ejecuta **antes** de tocar nada |
| `tools/inspect.sh` | Qué hace un paquete **sin abrirlo** (`dumpsys package`). `--list` muestra los que parecen del fabricante |
| `tools/disable.sh` | Deshabilita un lote pequeño con `pm disable-user --user 0` (un `pm` por llamada). Rechaza todo el lote si hay un paquete protegido |
| `tools/restore.sh` | **Script de restauración**: vuelve a habilitar todo lo deshabilitado y restaura el DNS privado |
| `tools/shot.sh` | Pulsa teclas y hace una captura del televisor |
| `tools/close-adb.sh` + `tools/adb-closed.py` | Cierra la depuración y comprueba que el puerto 5555 rechaza la conexión |
| `build-and-install.sh` | **Compila e instala** el lanzador y (si dices que sí) lo pone como Home |
| `launcher/` | Proyecto Android (Java + RecyclerView, `minSdk 26`, Android 9 = SDK 28) |

## Orden de trabajo

1. **En el televisor:** Ajustes > Preferencias del dispositivo > Acerca de > pulsa 7 veces en *Compilación*. Luego Opciones de desarrollador: activa *Depuración USB* y *Depuración de red/ADB*. Anota la IP (Ajustes > Red).
2. **Conectar:** `adb connect <IP>:5555` y acepta "¿Permitir depuración USB?" en el televisor. Después `export TV=<IP>:5555`.
   - macOS con `No route to host` aunque el puerto esté abierto: es la privacidad de red local bloqueando `adb`. Usa el paquete Python `adb-shell` en un entorno virtual.
   - Puerto 5555 cerrado: usa Depuración inalámbrica (`adb pair`, `adb connect`, `adb tcpip 5555`).
3. `tools/backup.sh` — mira el `SDK`, `ro.adb.secure` y el transporte (debe ser `WIFI`: tu televisor va por Wi-Fi y no tiene nada en los USB).
4. Instala primero el lanzador (`./build-and-install.sh`). Si el televisor responde `INSTALL_FAILED_VERIFICATION_FAILURE`, no admite APK externos: haz solo la limpieza y deja el lanzador de fábrica.
5. Comprueba con tus ojos que Home abre el lanzador nuevo; reinicia una vez y confirma que Home y `adb` vuelven.
6. Limpieza por lotes (abajo).
7. `tools/close-adb.sh`, reiniciar y `python3 tools/adb-closed.py <IP>`.

> Algunos televisores cortan la corriente de los USB mientras la depuración USB está activa. Desactívala al terminar.

## Limpieza: cómo hacerla

1. `tools/inspect.sh --list` y pega aquí el resultado. Yo lo clasifico en: telemetría, contenido y publicidad (PatchWall y filas de recomendaciones), servicios en segundo plano innecesarios, preinstaladas y streaming. **No he inventado nombres de paquetes de tu modelo**: dependen del firmware.
2. Crea `batches/01.txt` con 3–6 paquetes (un nombre por línea, `#` para comentar) y ejecuta `tools/disable.sh batches/01.txt`.
3. Mira el televisor: Home, mando, menú de entradas y HDMI. Solo entonces el siguiente lote.
4. Tras el último lote, **reinicia** y compara `adb shell pm list packages -d` con lo que deshabilitaste: algunos firmwares rehabilitan paquetes en cada arranque. Si pasa, anótalos aquí en lugar de desactivarlos tras cada arranque.

`disable.sh` **nunca** acepta: paquetes `android`, `com.android.systemui|shell|phone|settings|tv.settings`, permisos/instalador de paquetes, `ext.services`/`ext.shared`, metadatos de módulos, `overlay.modules*`, `com.android.providers.*` (salvo calendario, contactos, diccionario y números bloqueados), Play Store/Play Services, cualquier cosa con `bluetooth`, `inputmethod`, `keyboard`, `remote`, `tvinput`, el TV (`com.android.tv*`, `com.google.android.tv*`), paquetes `factory`/`fac.menu`/`com.at.*`, Netflix y Prime Video. Puedes añadir más patrones en `tools/protected-extra.txt`.
**Nunca abras** un paquete que se llame `factory`, `production`, `AT` o `fac menu` para "ver qué hace": usa `inspect.sh`.

Antes de tocar el asistente de voz, Chromecast/Miracast o el servicio de actualización, dime cuáles usas. Solo tengo confirmado que usas **Netflix y Amazon Prime**.

### Volver atrás

```
export TV=<IP>:5555
tools/restore.sh              # reactiva todo lo deshabilitado y restaura el DNS privado
```
Para un paquete suelto: `adb shell pm enable <paquete>`.
Si Home no abre el lanzador nuevo: `adb shell pm enable <lanzador-de-fabrica>` y `adb shell cmd package set-home-activity <paquete>/<actividad>` (los claimants de Home están en `backup/<fecha>/home-claimants.txt`), y reinicia.

## DNS con bloqueo de anuncios (opcional)

```
adb shell settings put global private_dns_specifier dns.adguard-dns.com
adb shell settings put global private_dns_mode hostname
```
**No bloquea los anuncios de YouTube.** Comprueba después que Netflix y Prime siguen funcionando. **Deshacer:** `adb shell settings put global private_dns_mode opportunistic` (o `tools/restore.sh`).

## Lanzador

- Fondo negro, dock en banda redondeada, cuadrícula debajo con las mismas columnas (se desplaza al pulsar Abajo), tile enfocado ampliado con su nombre, nombre grande del dock con brillo del color del banner, píldoras Entradas / Wi-Fi (muestra la red) / Ajustes, saludo + reloj + fecha en Outfit. Sin desenfoque, sin vídeo, sin red.
- El "cristal" es un relleno translúcido que se mueve de tile en tile (no hay bordes por tile).
- D-pad determinista: Arriba/Abajo mueve exactamente una fila; Arriba desde el dock va a la barra superior; los extremos no caen a otras zonas; recuerda el último tile.
- **Entradas** lista HDMI, AV y TV en vivo del `TvInputManager`. Abrirlas con `ACTION_VIEW` sobre el URI de la entrada funciona en la mayoría de televisores, pero **no está probado en el tuyo**.
- El nombre del Wi-Fi en Android 9 exige el permiso de ubicación: se pide una vez; si lo deniegas verás solo "Wi-Fi".
- Los botones Netflix/Prime/Entrada/Ajustes del mando los atiende el sistema, no este lanzador. Tras cambiar Home, **pulsa cada uno** y dime cuáles no hacen nada.

### Cambiar el orden del dock o las columnas
Edita `launcher/app/src/main/res/values/config.xml`:
```xml
<integer name="columns">4</integer>        <!-- 2 a 7: ranuras del dock Y columnas de la cuadrícula -->
<string-array name="dock_apps">
    <item>com.netflix.ninja</item>
    <item>com.amazon.amazonvideo.livingroom</item>
    ...
```
Los paquetes que no estén instalados se omiten. Para ver los nombres reales: `adb shell pm list packages | grep -i <nombre>`. Después `./build-and-install.sh` otra vez.

### Fondo de pantalla
Copia una imagen como `launcher/app/src/main/res/drawable-nodpi/wallpaper.jpg` (mejor ≤ 1920×1080 y pequeña: el televisor tiene ~1 GB de RAM), vuelve a ejecutar `./build-and-install.sh`. Sin ese archivo el fondo es negro puro. Para quitarlo, borra el archivo.

### Tipografía Outfit
`build-and-install.sh` intenta descargar Outfit (licencia SIL OFL). Si falla, descarga `Outfit[wght].ttf` de Google Fonts y guárdalo como `launcher/app/src/main/assets/fonts/Outfit.ttf`. Sin el archivo se usa una fuente ligera del sistema.

## Requisitos de compilación
JDK 17, Android SDK con plataforma 34 y build-tools (`ANDROID_HOME`), y `./gradlew` o `gradle` 8.4+. También puedes abrir `launcher/` en Android Studio y compilar la variante *debug*.

## Seguridad al terminar
`tools/close-adb.sh`, revoca las autorizaciones de depuración USB en Opciones de desarrollador, reinicia y ejecuta `python3 tools/adb-closed.py <IP>`: solo "Connection refused" demuestra que el puerto está cerrado. El 5555 va en texto plano y con `ro.adb.secure=0` cualquiera en tu red podría obtener una shell mientras esté abierto.

## Desde el móvil (Android + Termux)

1. Instala **Termux desde F-Droid** (la versión de Play Store está obsoleta). En Termux: `pkg install android-tools bash python curl unzip`.
2. Copia `tvkit.zip` al móvil y descomprímelo en Termux (`termux-setup-storage`, luego `unzip ~/storage/downloads/tvkit.zip`).
3. **APK sin compilar en el móvil:** crea un repositorio en GitHub, sube el contenido de `tvkit/` (incluye `.github/workflows/build.yml`), abre *Actions > Build launcher APK > Run workflow*, y descarga el artefacto `launcher-apk` (un zip con `app-debug.apk`). Guárdalo en la carpeta de Termux.
4. Móvil y televisor en la misma Wi-Fi: `adb connect IP_DEL_TV:5555`, `export TV=IP_DEL_TV:5555`, y sigue el orden normal. Para instalar: `APK=/ruta/app-debug.apk ./build-and-install.sh`.
No se puede hacer desde un iPhone: no hay un cliente adb práctico.
