#!/usr/bin/env bash
# Press keys and take a screenshot:  tools/shot.sh shots/01.png DPAD_RIGHT DPAD_DOWN
# With no keys it just captures the current screen. HDMI, live TV and Netflix show empty (0-byte) shots: that is the TV.
source "$(dirname "$0")/common.sh"
need_tv
OUT="${1:?usage: shot.sh out.png [KEY ...]}"; shift
for k in "$@"; do tvsh input keyevent "KEYCODE_${k#KEYCODE_}"; sleep 0.4; done
mkdir -p "$(dirname "$OUT")"
tvadb exec-out screencap -p > "$OUT"
if [ ! -s "$OUT" ]; then
  rm -f "$OUT"
  echo "Empty screenshot (protected content?). Top activity instead:"
  tvsh dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -2
  exit 1
fi
echo "saved $OUT"
