#!/usr/bin/env bash
# Shared helpers. Usage in other scripts:  source "$(dirname "$0")/common.sh"
# Set TV=<ip>:5555 (or the wireless-debugging address) before running anything.
ADB="${ADB:-adb}"
TV="${TV:-}"
KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKUP_ROOT="$KIT_ROOT/backup"

need_tv() {
  if [ -z "$TV" ]; then
    echo "Define the TV address first, e.g.:  export TV=192.168.1.50:5555" >&2
    exit 1
  fi
  if ! "$ADB" -s "$TV" get-state >/dev/null 2>&1; then
    echo "Cannot reach $TV with adb. Run:  adb connect $TV   (and accept the prompt on the TV)" >&2
    echo "Note: on macOS, 'No route to host' can be Local Network privacy blocking adb, see README." >&2
    exit 1
  fi
}

# one adb shell call per command (chained pm commands can stop silently after the first)
tvsh() { "$ADB" -s "$TV" shell "$@"; }
tvadb() { "$ADB" -s "$TV" "$@"; }

latest_backup() { cat "$BACKUP_ROOT/.latest" 2>/dev/null; }
